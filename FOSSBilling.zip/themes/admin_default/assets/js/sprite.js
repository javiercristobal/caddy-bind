const svgContext = require.context('../icons', false, /\.svg$/);
svgContext.keys().forEach(svgContext);
